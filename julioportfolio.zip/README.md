# Julio Ortiz — Eyemazing Design Portfolio

Complete, self-contained portfolio website for GitHub Pages.

## Upload
1. Extract this ZIP.
2. Upload index.html and .nojekyll to the root of your GitHub repository. Replace the old index.html.
3. Keep the filename exactly index.html (lowercase).
4. Use that repository root as your GitHub Pages publishing folder.

Do not upload the ZIP itself as the website. Upload the extracted files.

All seven project pages, About, images, styles, JavaScript, resume and portfolio PDF are included inside index.html. No extra asset folders, installation or build process is required. Project navigation works without depending on your repository name.
